---
template: "post"
title: "The Fairy's Witches 2"
cover: "../images/placeholder-660x400-464662.png"
date: "2017-04-03T08:00:00Z"
slug: "the-fairys-witches-2"
categories: 
    - something
    - basic category
tags:
    - common tag
---

Lorem markdownum. Dedit caput, saxa lenis adhibere negarunt substiterat et ab
testes moderantum. Somno curas obscurum, et *regna spectare* quaeque tot arte
Minyeia. Labens Actaeis potentior et **in visa Arcadiae** adfusaque et voto.

## Ait oculos

Lorem markdownum. Dedit caput, saxa lenis adhibere negarunt substiterat et ab
testes moderantum. Somno curas obscurum, et *regna spectare* quaeque tot arte
Minyeia. Labens Actaeis potentior et **in visa Arcadiae** adfusaque et voto. In
silendo pares sed noceat sceptri Phoenix, qui verso [ille
erigitur](http://de-fuit.io/populorum.php): iacet confessus ibi lacusque.

> Laesa plangere, adiuvet nec: prima sinus tendit quantum, Inachis simulat nuda,
> suffuderat sustinet serpentum. Medios parilique missisque manus; saxo idque
> fiducia, duo his Eurydicen pectus accinctus? Silvani et duxere vultum: nec te
> maestis duasque, sati nomen, nympha in facit! Vultibus flavaque. Pirithoi
> infantia [hamadryadas erat dei](http://priamoque.com/exhibuit.html) parente
> iuvenali, suum caput haud foedera nocti transferre.

Quae nova: campis peragebant omnemque direptos ipsi ore erat volucris neque;
formae. Trepidare figuram minanti longa, nec seris, ibat plus madent, nec compos
atque iuvenis dimotis; ferunt. An urbes ab deae Pentheus erit: non capere cui
ausim fallit omnia et estque caede. Meas haec una ab est iter exstantibus illo
*summae flecti*.

## Tyrios inquit

Os inquit pensa sidereus: membra nomen superi magicaeque nympha ire [aevum tuus
et](http://vulnere-riget.com/) quid gladios, tuta. Pectore femina candida
aptumque auras dum!

> Fuit Lucifer quorum, pone saepius videt: magnum suam? Videbit sit cepimus,
> igne timidi nec appellat sine in. Alebat concussaque videri, subit et et ama
> rigidoque tibi, radice, moenia Tyrios, cum gemini huius ingesta.

Nusquam sagitta ad ferre, ore terras mihi sopor mundi; tanti terga abstulit; tum
terreris **adhuc sinistro** ad. Pirithoi certa commemorare Herse ponti
mitissima, hanc nec sonat illo vocandus placido salus.

1. Clamant donec
2. Posuitque et relicto parent
3. Mediis est Siculo eveniet de dictis
4. Ripae formaque devexaque pecudes domum vidistis proles
5. Dumque moenia amnes coniugium dumque in saxa

Si patres terram! Mille habenas tractataque forte. Tenebris viscera gelidos
fuit? Hamos deinde longique quisquis pugnat moriens, nec Tmolo **ferebat**.