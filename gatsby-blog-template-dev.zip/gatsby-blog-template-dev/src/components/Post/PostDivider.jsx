import React from "react";

const PostDivider = () => (
  <div 
    className="post-divider border-bottom border-color-light-grey margin-bottom-half margin-top-half" 
  />
)

export default PostDivider;